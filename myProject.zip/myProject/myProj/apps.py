from django.apps import AppConfig


class MyprojConfig(AppConfig):
    name = 'myProj'
